# 🛠 Kubernetes Deployment Guide for Microservice-based eCommerce App

## 📦 Folder Structure
```
k8s/
├── mongodb/
├── user-service/
├── product-service/
├── cart-service/
├── order-service/
├── api-gateway/
├── frontend/
└── ingress.yaml
```

## 🚀 Steps to Deploy on Minikube

### 1. Start Minikube
```bash
minikube start
```

### 2. Enable Ingress Controller
```bash
minikube addons enable ingress
```

### 3. Apply Manifests
```bash
kubectl apply -f k8s/
```

### 4. Add Hosts Entry
Edit your `/etc/hosts` (Linux/macOS) or `C:\Windows\System32\drivers\etc\hosts` (Windows) and add:
```
127.0.0.1 ecommerce.local
```

### 5. Access the App
```bash
minikube tunnel
```
Then open:
```
http://ecommerce.local/
```

## ✅ Components Included
- MongoDB with Persistent Storage
- Internal Services for each microservice
- ConfigMaps for environment variables
- Ingress to route traffic
